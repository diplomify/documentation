---
hide:
  - footer
---

!!! box ""
    **Jedes Schuljahr**<br>

    :material-check:{ .success } [Schuljahre anlegen](../Administration/Schuljahre_anlegen.md)<br>
    :material-check:{ .success } [Schuljahresdaten angeben](../Administration/Termine_anlegen.md)<br>
    :material-check:{ .success } Zeugnisse zuweisen<!-- (../Administration/Zeugnisse!.md) --><br>
    :material-check:{ .success } [Schuljahre befüllen (Import)](../Administration/Import.md)<br>

!!! box ""
    **halbjährlich**<br>

    :material-check:{ .success } [Schuljahre befüllen (Import)](../Administration/Import.md)<br>
    :material-check:{ .success } Schüler importieren<br>
    :material-check:{ .success } Unterricht zuweisen<br>

!!! box ""
    **nur bei Änderungen**<br>

    :material-check:{ .success } Lehrkräfte importieren<br>
    :material-check:{ .success } [Fächer anlegen](../Administration/Fächer_anlegen.md)<br>

!!! box ""
    **einmalig bei  Erstinbetriebnahme**<br>

    :material-check:{ .success } [Fächer anlegen](../Administration/Fächer_anlegen.md)<br>
    :material-check:{ .success } Floskeln hinterlegen<br>
    :material-check:{ .success } Zeugnisse anlegen<br>
    :material-check:{ .success } Zeugnisgruppen anlegen<br>
    :material-check:{ .success } ILE-formulare erstellen<br>

!!! box ""
    **empfohlen - nach Bedarf**<br>

    :material-check:{ .success } [Backup anlegen](../Administration/Backup.md)<br>

!!! box ""
    **optional**<br>

    :material-check:{ .success } WebUntis-Integration anlegen<br>
    :material-check:{ .success } Floskeln für Förderbedarfe anlegen<br>
