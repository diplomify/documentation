---
hide:
  - footer
---

Navigiere dazu im Adminbereich in "Berichte" und wähle das passende Halbjahr aus.
Der Druck wird über "Versetzungswarnungen drucken ausgelöst."

!!! warning ""
    Versetzungswarnungen können nur im 2. Halbjahr ausgesprochen werden. Im ersten Halbjar wird der Button nicht angezeigt.

Nun wird in einem neuen Browser-Tab der Warnungs-Report für die gesamte Schule im gewählten Halbjar erstellt. 