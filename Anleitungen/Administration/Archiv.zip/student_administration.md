---
hide:
  - footer
---

# Die Schüler*innenverwaltung

![Image title](/img/01_Administration/student_list.png){ .img-head }


##Übersicht

###Schüler*innen verwalten


#####Schülerinnen anlegen


#####Schülerinnen importieren


###Schüler*in - Stammdaten bearbeiten
Alle Daten gelten rückwirkend
Aber: wenn Zeignisse bereits erstellt und als pdf gespeichert wurden, bleibt das erhalten.

###Schüler*in löschen
