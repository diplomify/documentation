hide:
  - footer
---

## 1. Admin festlegen/entziehen

## 2. Klassenleitung bestätigen/zuweisen

## 3. Klassenadmin/ILE-Admin zuweisen