---
hide:
    - footer
---


<iframe width="560" height="315" src="https://www.youtube.com/embed/qb5SaHANpUI?si=mmgiXX-FFUwjNvBC" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" referrerpolicy="strict-origin-when-cross-origin" allowfullscreen></iframe>

<br>

!!! note ""
    Das Infocenter dient zur Klärung wiederkehrender Fragen und Übermittlung wichtiger aktueller Informationen an das Kollegium.

<br>

## Das Infocenter befüllen
!!! bread ""
    Administrationsbereich > Infocenter
<br>
Klicken Sie im Adminbereich > Infocenter auf "Artikel hinzufügen" und nehmen die gewünschten Eintragungen und Einstellungen vor. <br>
Oder klicken Sie im Infocenter im Nutzerbereich auf "Artikel editieren" bzw. "Artikel hinzufügen". (Nur für Admins sichtbar.)

###Titel
Artikel werden für Nutzer immer als aufklappbare Listeneinträge angezeigt. <br>
Es ist daher wichtig, dass Sie aussagekräftige Titel wählen.

###Textfeld
Hier können die gewünschten Informationen eingetragen werden. Es steht zusätzlich eine Formatierungspalette zur Verfügung.
Absätze können mit ++enter++ angelegt werden.

###Tags
Tags sind kleine farbige Hinweise, die zusätzlich Informationen über die Art und Wichtigkeit der Artikel geben. Sie helfen ihren Kolleg/innen, schnell die wichtigen Einträge zu finden.
Tags sind optional und können einzeln oder mehrfach vergeben werden. 

###Warnmeldungen
Warnmeldungen werden im Infocenter in einem roten Kasten über allen anderen Artikeln angezeigt und lösen einen zählenden Indikator am Menüeintrag "Infocenter" aus.
Sobald eine Lehrkraft das Infocenter geöffnet hat, wird der Indikator nicht mehr angezeigt.
Sollten Sie also besonders wichtige Meldungen erstellen wollen, nutzen Sie die Checkbox "Als Warnmeldung anzeigen"